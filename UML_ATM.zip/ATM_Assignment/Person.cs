﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
   public class Person
    {
        public string FirsName{get;set;}
        public string LastName { get; set; }
      

    }
}
