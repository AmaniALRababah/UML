﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Assignment
{
    public class BankAccount
    {
        public Person user { get; set; }
        public string Email { get; set; }
        public string CardNumber { get; set; }
        public string PinCode { get; set; }
        public int AccountBalance { get; set; }

        public BankAccount(Person p1, string v, string cardNumber, string pinCode, int accountBalance)
        {
            this.user = p1;
           
            this.Email = v;
            this.CardNumber = cardNumber;
            this.PinCode = pinCode;
            this.AccountBalance = accountBalance;
        }
    }
}
