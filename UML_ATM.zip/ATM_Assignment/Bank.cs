﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ATM_Assignment
{
   public class Bank
    {
        public int BankCapacity { get; set; }
        public int NumberOfCustomers   { get; set; }
      

        public Bank(int bankCapacity)
        {
            this.BankCapacity = bankCapacity;
            this.NumberOfCustomers = 0;
            acoounts = new BankAccount[bankCapacity];
        }

        public Bank()
        {
            this.BankCapacity = 10;
            this.NumberOfCustomers = 0;
            acoounts = new BankAccount[BankCapacity];
        }

        public BankAccount[] acoounts { get; }

        public void AddNewAccount(BankAccount tmpAccount)
        {
            if (NumberOfCustomers < BankCapacity)
            {
                acoounts[NumberOfCustomers++] = tmpAccount;
            }
        }

        public bool IsBankUser(string Number, string Code)
        {
            bool is_ = false;
           for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (acoounts[i].CardNumber.Equals(Number) && acoounts[i].PinCode.Equals(Code))
                    is_ = true;
                
            }
            return is_;
        }

        public int CheckBalance(string Number, string Code)
        {
            int is_ = 0;
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (acoounts[i].CardNumber.Equals(Number) && acoounts[i].PinCode.Equals(Code))
                    is_ = acoounts[i].AccountBalance;

            }
            return is_;

        }

        public void Withdraw(BankAccount A, int withdrawAmount)
        {
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (acoounts[i].CardNumber.Equals(A.CardNumber) && acoounts[i].PinCode.Equals(A.PinCode))
                {
                    if(withdrawAmount <= acoounts[i].AccountBalance)
                    acoounts[i].AccountBalance -= withdrawAmount;
                }

            }
        }

        public void Deposit(BankAccount A, int D)
        {
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                if (acoounts[i].CardNumber.Equals(A.CardNumber) && acoounts[i].PinCode.Equals(A.PinCode))
                {
                    
                        acoounts[i].AccountBalance += D;
                }

            }
        }

        public void Save()
        {
            string text = "";
            for (int i = 0; i < NumberOfCustomers; i++)
            {
                text += acoounts[i].CardNumber + "\t" + acoounts[i].PinCode + "\t" + acoounts[i].Email + "\t" + acoounts[i].AccountBalance + "\t" + acoounts[i].user.FirsName + "\t" + acoounts[i].user.LastName + "\n";

            }
            string myDocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string filename = Path.Combine(myDocuments, "File.txt");
            File.WriteAllText(filename, text);
        }

        public void Load()
        {
            string myDocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string filename = Path.Combine(myDocuments, "File.txt");
            string[] data = File.ReadAllLines(filename);
            this.BankCapacity = data.Length;
            this.NumberOfCustomers =0;
            for(int i=0;i<data.Length; i++)
            {
                string[] data2 = data[i].Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);
                Person t = new Person();
                t.FirsName = data2[5];
                t.LastName = data2[4];
                BankAccount n = new BankAccount(t, data2[2], data2[0], data2[1], int.Parse(data2[3]));
                acoounts[NumberOfCustomers++] = n;
            }
           


        }
    }
}
