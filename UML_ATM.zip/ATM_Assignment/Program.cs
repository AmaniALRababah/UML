﻿using System;
using System.IO;

namespace ATM_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
          

          
        }
    }
}
